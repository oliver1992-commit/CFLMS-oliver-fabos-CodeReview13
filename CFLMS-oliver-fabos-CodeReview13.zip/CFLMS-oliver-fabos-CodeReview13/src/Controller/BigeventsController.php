<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use App\Entity\Bigevents;

class BigeventsController extends AbstractController
{
    /**
    * @Route("/", name="front_page")
    */
    public function front_page()
    {
        return $this->render('bigevents/front_page.html.twig');
    }

    /**
    * @Route("/index", name="home_page")
    */
   public function showAction()
   {
    $todos = $this->getDoctrine()->getRepository('App:Bigevents')->findAll();
     
    return $this->render('bigevents/index.html.twig', array('todos'=>$todos));

// it retrieves all values from the date base, and send to the /index.html.twig tamplate
}
   
   /**
    * @Route("/create", name="create_page")
    */
   public function createAction(Request $request)
   {
         // we create a new object from our class
         $todo = new Bigevents;
         /* with the help of the creatFormBuilder we create a form and we set the attributes to the inputs */
                $form = $this->createFormBuilder($todo)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
                ->add('datetime', DateTimeType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
                ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
                ->add('capacity', TextType::class, array('attr' => array('style'=>'margin-bottom:15px')))
            ->add('e_mail', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('phone_number', TextType::class, array('attr' => array('style'=>'margin-bottom:15px')))
            ->add('city', TextType::class, array('attr' => array('style'=>'margin-bottom:15px')))
            ->add('zip_code', TextType::class, array('attr' => array('style'=>'margin-bottom:15px')))
            ->add('address', TextType::class, array('attr' => array('style'=>'margin-bottom:15px')))
            ->add('event_type', ChoiceType::class, array('choices'=>array('Music'=>'Music', 'Sport'=>'Sport', 'Movie'=>'Movie', 'Theater'=>'Theater', 'Cabaret'=>'Cabaret'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
            ->add('image', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('save', SubmitType::class, array('label'=> 'Create Record', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:15px')))
                ->getForm();
                $form->handleRequest($request);
                
         
               /* if statment trigers the input values and saves in these variables */
                if($form->isSubmitted() && $form->isValid()){
                    //fetching data
         
                   /* getDate() function helps to take the values from the input */
                    $name = $form['name']->getData();
                    $datetime = $form['datetime']->getData();
                    $description = $form['description']->getData();
                    $capacity = $form['capacity']->getData();
                    $e_mail = $form['e_mail']->getData();
                    $phone_number = $form['phone_number']->getData();
                    $city = $form['city']->getData();
                    $zip_code = $form['zip_code']->getData();
                    $address = $form['address']->getData();
                    $event_type = $form['event_type']->getData();
                    $image = $form['image']->getData();
                    
                    // Here we will get the current date
                    $now = new\DateTime('now');
         
         /* the retrived vales from the entity helps to set the values */
                    $todo->setName($name);
                    $todo->setDatetime($datetime);
                    $todo->setDescription($description);
                    $todo->setCapacity($capacity);
                    $todo->setEMail($e_mail);
                    $todo->setPhoneNumber($phone_number);
                    $todo->setCity($city);
                    $todo->setZipCode($zip_code);
                    $todo->setAddress($address);
                    $todo->setEventType($event_type);
                    $todo->setImage($image);
                    $todo->setCreateDate($now);
                    $em = $this->getDoctrine()->getManager();
                    $em->persist($todo);
                    $em->flush();
                    $this->addFlash(
                            'notice',
                            'Record Added'
                            );
                    return $this->redirectToRoute('home_page');
                }
         /* we call the bild in function for the form to creat the view  */
                return $this->render('bigevents/create.html.twig', array('form' => $form->createView()));
            }
         
      /**
    * @Route("/edit/{id}", name="todo_edit")
    */
   public function editAction( $id, Request $request){
    /* the created variable saves the the value for the search */
       $todo = $this->getDoctrine()->getRepository('App:Bigevents')->find($id);
    $now = new\DateTime('now');
    /* we set the already existing values */
                $todo->setName($todo->getName());
               $todo->setDatetime($todo->getDatetime());
               $todo->setDescription($todo->getDescription());
               $todo->setCapacity($todo->getCapacity());
               $todo->setEMail($todo->getEMail());
               $todo->setPhoneNumber($todo->getPhoneNumber());
               $todo->setCity($todo->getCity());
               $todo->setZipCode($todo->getZipCode());
               $todo->setAddress($todo->getAddress());
               $todo->setEventType($todo->getEventType());
               $todo->setImage($todo->getImage());
               $todo->setCreateDate($now);
    /*create 'form' bilder for edit*/
    $form = $this->createFormBuilder($todo)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
    ->add('datetime', DateTimeType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
    ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
    ->add('capacity', TextType::class, array('attr' => array('style'=>'margin-bottom:15px')))
->add('e_mail', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
->add('phone_number', TextType::class, array('attr' => array('style'=>'margin-bottom:15px')))
->add('city', TextType::class, array('attr' => array('style'=>'margin-bottom:15px')))
->add('zip_code', TextType::class, array('attr' => array('style'=>'margin-bottom:15px')))
->add('address', TextType::class, array('attr' => array('style'=>'margin-bottom:15px')))
->add('event_type', ChoiceType::class, array('choices'=>array('Music'=>'Music', 'Sport'=>'Sport', 'Movie'=>'Movie', 'Theater'=>'Theater', 'Cabaret'=>'Cabaret'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
->add('image', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
->add('save', SubmitType::class, array('label'=> 'Update Record', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:15px')))
           ->getForm();
           $form->handleRequest($request);
           if($form->isSubmitted() && $form->isValid()){
               //fetching data
               $name = $form['name']->getData();
               $datetime = $form['datetime']->getData();
               $description = $form['description']->getData();
               $capacity = $form['capacity']->getData();
               $e_mail = $form['e_mail']->getData();
               $phone_number = $form['phone_number']->getData();
               $city = $form['city']->getData();
               $zip_code = $form['zip_code']->getData();
               $address = $form['address']->getData();
               $event_type = $form['event_type']->getData();
               $image = $form['image']->getData();
               $now = new\DateTime('now');
               $em = $this->getDoctrine()->getManager();
               $todo = $em->getRepository('App:Bigevents')->find($id);
               $todo->setName($name);
               $todo->setDatetime($datetime);
               $todo->setDescription($description);
               $todo->setCapacity($capacity);
               $todo->setEMail($e_mail);
               $todo->setPhoneNumber($phone_number);
               $todo->setCity($city);
               $todo->setZipCode($zip_code);
               $todo->setAddress($address);
               $todo->setEventType($event_type);
               $todo->setImage($image);
               $todo->setCreateDate($now);
           
               $em->flush();
               $this->addFlash(
                       'notice',
                       'Record Updated'
                       );
               return $this->redirectToRoute('home_page');
           }
           return $this->render('bigevents/edit.html.twig', array('todo' => $todo, 'form' => $form->createView()));
   
   }

   /**
    * @Route("/details/{id}", name="details_page")
    */
   public function detailsAction($id)
   {
    $todo = $this->getDoctrine()->getRepository('App:Bigevents')->find($id);
    return $this->render('bigevents/details.html.twig', array('todo' => $todo));
   }

   
    /**
    * @Route("/delete/{id}", name="todo_delete")
    */
    public function deleteAction($id){
        $em = $this->getDoctrine()->getManager();
   $todo = $em->getRepository('App:Bigevents')->find($id);
   $em->remove($todo);
    $em->flush();
   $this->addFlash(
           'notice',
           'Record Removed'
           );
    return $this->redirectToRoute('home_page');
}

}

?>
